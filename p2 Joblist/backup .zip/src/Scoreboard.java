import java.util.Iterator;

public class Scoreboard implements ScoreboardADT {
	
//  JobList cJobs;
	ListADT<Job> cJobs;

	
	public Scoreboard() {
		cJobs = new JobList<Job>();		
	}
	
	 /**
     * Calculates the total combined number of points for every job 
     * in the scoreboard.
     * 
     * @return The summation of all the points for every job currently 
     * stored in the scoreboard.
     */
	@Override
	public int getTotalScore() {
		// TODO Auto-generated method stub
		
		int totalscore = 0;
		Iterator<Job> itr = cJobs.iterator();
		while (itr.hasNext()) {
			totalscore += itr.next().getPoints();
		}
		return totalscore;
	}

	 /**
     * Inserts the given job at the end of the scoreboard.
     * 
     * @param job 
     * 		The job that has been completed and is to be inserted 
     * 		into the list.
     */
	@Override
	public void updateScoreBoard(Job job) {
		// TODO Auto-generated method stub
		
		if (job.isCompleted()) {
			cJobs.add(job);
		}
	}

	/**
     * Prints out a summary of all jobs currently stored in the scoreboard.
     * The formatting must match the example exactly.
     */
	@Override
	public void displayScoreBoard() {
		// TODO Auto-generated method stub
		System.out.println("default");		
	}	

}
