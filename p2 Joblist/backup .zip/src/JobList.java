import java.util.Iterator;
@SuppressWarnings("hiding")
public class JobList<Job> implements ListADT<Job> {	
	
	// implemented as a singly-linked chain of Listnode<Job> nodes  
	// with a header node and without a tail reference
		
	private Listnode<Job> head;
	private int numItems;
		
	public JobList() {	
		head = new Listnode<Job>(null);
		numItems = 0;
	}
		
	@Override
	public Iterator<Job> iterator() {
		return new JobListIterator<Job>(head);	
	}	

	@Override
	public void add(Job item) {
		if (item == null) throw new IllegalArgumentException();		
		Listnode<Job> newnode = new Listnode<Job>(item);
		
		// non-empty or empty list both have a header node
		Listnode<Job> curr = head; // header node
		while (curr.getNext() != null)
			curr = curr.getNext();
		curr.setNext(newnode);
		numItems++;
	}

	@Override
	public void add(int pos, Job item) {

		// check for invalid position and for full array
		if (pos < 0 || pos > numItems) throw new IndexOutOfBoundsException();	
		
		// if asked to add to end, let the other add method do the work
		if (pos == numItems) {
			add(item);
			return;
		}
		
		// find the node n after which to add a new node and add the new node
		Listnode<Job> n = head;
		for (int i = 0; i < pos; i++) {
			n = n.getNext();	
		}
		n.setNext(new Listnode<Job>(item, n.getNext()));
		numItems++;		
	}

	@Override
	public boolean contains(Job item) {
		// TODO Auto-generated method stub
		if (item == null)
			throw new IllegalArgumentException();
		for (int i = 0; i < numItems; i++) {
			if (item.equals(item))
				return true;
		}
		return false;
	}

	@Override
	public Job get(int pos) {

		// check for invalid position
		if (pos < 0 || pos >= numItems) throw new IndexOutOfBoundsException();	
		Listnode<Job> curr = head;
		for (int p = 0; p < pos; p++)
			curr = curr.getNext();
		return curr.getData();
	}

	@Override
	public boolean isEmpty() {		
		if (numItems == 0) 	return true;					
	return false;
	}

	@Override
	public Job remove(int pos) {

		// check invalid position
		if (pos < 0 || pos >= numItems)	 throw new IndexOutOfBoundsException();		
		Listnode<Job> curr = head;
		
//		// special case: pos is the first node in the list
//		if (pos == 0)  
//			head = curr.getNext();
		
		// general case: find the node before pos, then unlink pos
		for (int p = 0; p < pos; p++ )  curr = curr.getNext();			
		
		Job temp = curr.getNext().getData();
		curr.setNext(curr.getNext().getNext());
		
		return temp;
		
	}

	@Override
	public int size() {
		return numItems;
	}	
		
}

