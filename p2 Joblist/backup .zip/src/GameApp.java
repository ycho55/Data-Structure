import java.util.Scanner;

public class GameApp{
    /**
     * Scanner instance for reading input from console
     */
    private static final Scanner STDIN = new Scanner(System.in);

    /**
     * Constructor for instantiating game class
     * @param seed: Seed value as processed in command line
     * @param timeToPlay: Total time to play from command line
     */
    public GameApp(int seed, int timeToPlay){
        //TODO: Create a new instance of Game class
    	
    	
    }

    /**
     * Main function which takes the command line arguments and instantiate the
     * GameApp class.
     * The main function terminates when the game ends.
     * Use the getIntegerInput function to read inputs from console
     *
     * @param args: Command line arguments <seed> <timeToPlay>
     */
    public static void main(String[] args){

        System.out.println("Welcome to the Job Market!");

        //TODO: Take input from command line, process it and add error checking
        if (args.length != 2) {
        	System.exit(0);
        }
        int m = Integer.parseInt(args[0]);
        int n = Integer.parseInt(args[1]);
        if (m <= 0 || n <= 0) {
        	System.exit(0);
        }
       
        System.out.println("You have" + n + "left in the game!");
        Game curr = new Game(m, n);
        curr.displayActiveJobs();
        
        //Prompt the user for an index of a job to work on.
        System.out.println("Select a job to work on: ");
        Scanner in = new Scanner(System.in);
        int num;
        num = in.nextInt();        
        
        // game bug ? if input is negatived 
        int timeleft = 0;
        if (num != 0) {
        	timeleft = curr.getTimeToPlay() - num;
        	curr.setTimeToPlay(timeleft);
        }
        
        //Prompt the user for an amount of time to work on this job
        System.out.println("For how long would you like to work on this job?: ");
        Scanner in2 = new Scanner(System.in);
        int num2;
        num2 = in2.nextInt();
        if (num2 <= 0 || num2 > curr.getTimeToPlay()) {
        	
        	// exception here
        	System.out.println("wrong time");
        }
        
        // use getList method 
        Job demand = curr.getList().get(num);
        curr.updateJob(num, num2);
        
        // Prompt the user for an index to insert the element back into the list
        Scanner in3 = new Scanner(System.in);
        int num3;
        num3 = in3.nextInt();
        if ( !demand.isCompleted()) {
        	if (num3 > curr.getList().size()) {
        		curr.getList().add(demand);
        	}
        	curr.getList().add(num3, demand);
        }
        int timeleft1 = 0;
        if (num3 != 0 ) {
        	if (num3 > curr.getList().size()) {
        		timeleft1 = curr.getTimeToPlay() - curr.getList().size();
            	curr.setTimeToPlay(timeleft1);
        	}
        	timeleft1 = curr.getTimeToPlay() - num3;
        	curr.setTimeToPlay(timeleft1);
        }
        
        		
        
        
        //TODO: Call the start() method to start playing the game
    }

    /**
     * Add Comments as per implementation
     */
    private void start(){
    	
        //TODO: The interactive game logic goes here
    }

    /**
     * Displays the prompt and returns the integer entered by the user
     * to the standard input stream.
     *
     * Does not return until the user enters an integer.
     * Does not check the integer value in any way.
     * @param prompt The user prompt to display before waiting for this integer.
     */
    public static int getIntegerInput(String prompt) {
        System.out.print(prompt);
        while ( ! STDIN.hasNextInt() ) {
            System.out.print(STDIN.next()+" is not an int.  Please enter an integer.");
        }
        return STDIN.nextInt();
    }
}