import java.util.Iterator;
import java.util.NoSuchElementException;

@SuppressWarnings("hiding")
public class JobListIterator<Job> implements Iterator<Job>{

	private JobList<Job> list;
	private int curPos;
	
	// constructor
	public JobListIterator(JobList<Job> list) {
		this.list = list;
		curPos = 0;
	}
	
	@Override
	public boolean hasNext() {
		return curPos < list.size();
	}

	@Override
	public Job next() {
		if(!hasNext()) {
			throw new NoSuchElementException();
		}
		Job result = list.get(curPos);
		curPos++;
		return result;
	}
	
	public void remove() {
		throw new UnsupportedOperationException();
	}
}	
	
	
//	
//	private Listnode<Job> cur;
//	
//	JobListIterator(Listnode<Job> head) { cur = head; }
//
//	@Override
//	public boolean hasNext() {
//		return false;	
//	}
//
//	@Override
//	public Job next() {
//		if (!hasNext()) throw new NoSuchElementException();	
//		Job result = cur.getData();
//		cur = cur.getNext();
//		return result;
//	}
//	
//	public void remove() {
//		throw new UnsupportedOperationException();
//	}
//}
